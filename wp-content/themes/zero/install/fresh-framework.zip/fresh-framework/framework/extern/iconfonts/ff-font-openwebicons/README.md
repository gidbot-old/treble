OpenWeb Icons
============

The *OpenWeb Icons* are a set of icons to show the support for the *Open Web*!

You can find more informations and a list of all icons here: http://pfefferle.github.io/openwebicons/

[![endorse](http://api.coderwall.com/pfefferle/endorsecount.png)](http://coderwall.com/pfefferle)
