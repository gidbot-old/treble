# StateFace

A font you can use in your web apps when you want tiny state shapes as a design element. [Documentation](http://propublica.github.com/stateface/)
