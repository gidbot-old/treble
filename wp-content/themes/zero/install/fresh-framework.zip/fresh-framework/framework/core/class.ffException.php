<?php

class ffException extends Exception {
	
}