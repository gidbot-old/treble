<?php

class ffConstHTMLClasses {
	
	const POST_META_CATEGORIES_LINK = 'ff-category-meta';
	const POST_META_CATEGORIES_LINK_SPECIFIC = 'ff-category-meta-';
	
	const POST_META_CATEGORIES_LINK_SEPARATOR = 'ff-category-meta-separator';
	const POST_META_CATEGORIES_LINK_SEPARATOR_SPECIFIC = 'ff-category-meta-separator-';
	
}