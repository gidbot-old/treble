<?php

class ffModalWindowLibraryAddGroup extends ffModalWindow {
	protected function _initialize() {
		$this->_setMenuName('Add Group');
	}
}